<?php
ob_start();
if ($_POST) {
    include './shreeLib/DBAdapter.php';
    $dba = new DBAdapter();
    $_POST['user_pass'] = md5($_POST['user_pass']);
    $msg;
    $data = $dba->getRow("create_user", array("*"), "user_login_username='" . $_POST['user_username'] . "' and user_login_password='" . $_POST['user_pass'] . "'");
    //print_r($data);
    if (!empty($data)) {
        if ($_POST['user_username'] === $data[0][8] && $_POST['user_pass'] === $data[0][9]) {

            $data1 = $dba->getRow("create_branch INNER JOIN create_user ON create_branch.id=create_user.branch_id", array("create_branch.branch_status"), "create_branch.branch_status='true' AND create_user.id=" . $data[0][0] . " GROUP BY create_branch.id");
            if ($data1[0][0] == 'true') {
                session_start();
                $_SESSION['user_login_username'] = $data[0][8];
                $_SESSION['user_id'] = $data[0][0];
                // $_SESSION['party_id'] = 1;
                header("Location:Dashboard.php");
            } else {
                $msg = "Your Branch is Disable!";
            }
        } else {
            $msg = "Authentication Fail!";
        }
    } else {
        $msg = "Authentication Fails!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <base href="http://demo.bpiindia.in/">

        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>Login | Blue Pearl International</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
        <script src="https://www.gstatic.com/firebasejs/6.0.2/firebase.js"></script>

<script>
            var firebaseConfig = {
                apiKey: "AIzaSyBr3R7w9wlq05ZxBtdOVmrQztB5fVa3-xQ",
                authDomain: "account-657f6.firebaseapp.com",
                databaseURL: "https://account-657f6.firebaseio.com",
                projectId: "account-657f6",
                storageBucket: "account-657f6.appspot.com",
                messagingSenderId: "722396636779",
//                appId: "1:722396636779:web:17cb8ad1e2a2bef6"
            };
            firebase.initializeApp(firebaseConfig);


            const messaging = firebase.messaging();
            messaging.requestPermission().then(function () {
                console.log('Notification permission granted.');
//                if (isTokenSentToServer()) {
//                    console.log('oken already saved..');
//                } else {
                getRegToken();
//                }
            }).catch(function (err) {
                console.log('Unable to get permission to notify.', err);
            });

            function getRegToken(argument) {

                messaging.getToken()
                        .then(function (currentToken) {
                            if (currentToken) {
                                //                                sendTokenToServer(currentToken);
                                console.log(currentToken);
                                setTokenSentToServer(true);
                            } else {
                                console.log('No Instance ID token available. Request permission to generate one.');
                                setTokenSentToServer(false);
                            }
                        })
                        .catch(function (err) {
                            console.log('An error occurred while retrieving token. ', err);
                            showToken('Error retrieving Instance ID token. ', err);
                            setTokenSentToServer(false);
                        });

            }
            function setTokenSentToServer(sent) {
                window.localStorage.setItem('sentToServer', sent ? 1 : 0);
            }
            function isTokenSentToServer() {
                return window.localStorage.getItem('sentToServer') == 1;
            }
            messaging.onMessage(function (payload) {
                console.log('Message received. ', payload);
                notificationTitle =payload.data.title;
                notificationOptions ={
                    body:payload.data.body
                    
                }
                
                var notification = new Notification(notificationTitle, notificationOptions);
            });

        </script>
    </head>

    <body>

        <!-- Background -->
        <div class="account-pages"></div>
        <!-- Begin page -->
        <div class="wrapper-page">

            <div class="card">
                <div class="card-body">

<!--                    <h3 class="text-center m-0">
                        <a href="index.php" class="logo logo-admin"><img src="logo/logo-1.png" height="80" alt="logo"></a>
                    </h3>-->

                    <div class="p-3">
                        <h4 class="text-muted font-18 m-b-5 text-center">Welcome Back !</h4>
                        <p class="text-muted text-center">Sign in to continue to Blue Pearl International</p>

                        <form class="form-horizontal m-t-30" action="index.php" method="post">

                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" id="username" name="user_username" placeholder="Enter username">
                            </div>

                            <div class="form-group">
                                <label for="userpassword">Password</label>
                                <input type="password" class="form-control" id="password" name="user_pass" placeholder="Enter password">
                            </div>

                            <div class="form-group ">                               
                                <div class="">
                                    <button class="btn btn-primary btn-block w-md waves-effect waves-light" type="submit">Log In</button>

                                </div>

                            </div>
                             <?php
                        if ($_POST) {
                            echo $msg;
                        }
                        ?>
                            <div class="form-group m-t-10 mb-0 row">
                                <div class="col-12 m-t-20">
                                    <a href="pages-recoverpw.html" class="text-muted"><i class="mdi mdi-lock"></i> Forgot your password?</a>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>


        </div>

        <!-- END wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

<!--        <script src="assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

         App js 
        <script src="assets/js/app.js"></script>-->

    </body>

</html>