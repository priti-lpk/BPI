<?php

include_once '../shreeLib/DBAdapter.php';

include_once '../shreeLib/dbconn.php';

$dba = new DBAdapter();

if ($_POST['action'] == 'add') {
    unset($_POST['action']);
    unset($_POST['id']);
    $image_name = "";
    $k = 1;

    $filename = $_FILES["image"]["name"];
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    $lastID = $dba->getLastID("id", "question_master", "1");
    $imgefolder = ($lastID + 1) . "." . $ext;
    // $image_name = trim(($image_name . "," . $imgefolder), ',');
    $file = array("jpg", "jpeg", "png");
   move_uploaded_file($_FILES['image']['tmp_name'], '../Images/question/' . $imgefolder);
    if ($_FILES['image']['name']) {

        $_POST['image'] = $imgefolder;
    } else {

        $_POST['image'] = "";
    }
    $_POST['tag_id'] = implode(",", $_POST['tag_id']);
    $dba->setData("question_master", $_POST);

    header('location:../add_question.php');
} elseif ($_POST['action'] == 'edit') {

    unset($_POST['action']);
    $id = $_POST['id'];
    echo $id;
    $image_name = "";
    $k = 1;
    $filename = $_FILES["image"]["name"];
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    $imgefolder = ($id) . "." . $ext;
    // $image_name = trim(($image_name . "," . $imgefolder), ',');
    $file = array("jpg", "jpeg", "png");
    move_uploaded_file($_FILES['image']['tmp_name'], '../Images/question/' . $imgefolder);
    if ($_FILES['image']['name']) {

        $_POST['image'] = $imgefolder;
    } else {

        $_POST['image'] = "";
    }
    $_POST['tag_id'] = implode(",", $_POST['tag_id']);

    if ($dba->updateRow("question_master", $_POST, "id=" . $id)) {

        $msg = " Edit Successfully";
//        echo "<script>alert('Successfully Edited Main Category);top.location='../main_category.php';</script>";

//        header('location:../add_question.php');
    } else {

        $msg = "Edit Fail Try Again";
    }
}
?>



