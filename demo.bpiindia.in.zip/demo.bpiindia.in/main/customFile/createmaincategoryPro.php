<?php

ob_start();
include '../shreeLib/DBAdapter.php';
include_once '../shreeLib/dbconn.php';
include_once '../shreeLib/Controls.php';
if ($_POST['action'] == 'add') {
    $dba = new DBAdapter();
    unset($_POST['action']);
    unset($_POST['id']);
    $image_name = "";
    $filename = $_FILES["main_image"]["name"];
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    $lastID = $dba->getLastID("id", "main_category", "1");
    $imgefolder = ($lastID + 1) . "." . $ext;
    $file = array("jpg", "jpeg", "png");
    move_uploaded_file($_FILES['main_image']['tmp_name'], '../Images/main/' . $imgefolder);
    if ($_FILES['main_image']['name']) {

        $_POST['main_image'] = $imgefolder;
    } else {

        $_POST['main_image'] = "";
    }
    $dba->setData("main_category", $_POST);

    unset($_POST);
}
?>

