<footer class="footer">
    <b>Develop By : </b> <a href="http://lpktechnosoft.com" target="_blank"> LPK Technosoft</a>
</footer>

